'use strict';

angular.module('myApp.constants', [])
        .constant('AppConfig', {
          appName: 'YAAYorNAAY',
          endpoint: 'https://example.domain.com/api2/v1/'
        });
