
function initializeCordovaApplication() {
}

document.addEventListener('deviceready', initializeCordovaApplication, false);